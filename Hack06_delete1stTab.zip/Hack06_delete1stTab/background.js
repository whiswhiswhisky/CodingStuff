// Created by Wenjing Liu on Mar 3, 2019
//Tab Control Extension
// An exntension that delete your first tab when you create a new one

console.log("background is here!")

chrome.tabs.onCreated.addListener(function(tab){
  console.log(tab.id);
  console.log("A New Tab Is Created!!")

  //get all tabs
  chrome.tabs.query({},function(tabs) {
    console.log("There are " + tabs.length + " tabs in total.")

    if (tabs.length > 5){
    //remove the first tab
    chrome.tabs.remove(tabs[0].id,function(tab){
    console.log("The first tab is removed!")

    //send a message to the current tab page
    chrome.tabs.query({'active':true, 'currentWindow':true},function(newtabs) {
      let thisTab = newtabs[0];
      console.log("the current tab is " + thisTab.id);
      chrome.tabs.sendMessage(thisTab.id, {"message": "aha"});
    });

    });
    }

  });
});
