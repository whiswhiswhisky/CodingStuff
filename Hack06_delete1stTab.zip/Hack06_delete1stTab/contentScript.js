console.log("why not?")

chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    if(request.message === "aha") {
      console.log(request.message);
      $("div").html("YOU OPENED TOO MANY TABS. STAY FOCUS.");
    }
  }
);
